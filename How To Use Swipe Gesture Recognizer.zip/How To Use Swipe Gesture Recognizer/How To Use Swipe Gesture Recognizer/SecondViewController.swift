//
//  SecondViewController.swift
//  How To Use Swipe Gesture Recognizer
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 12/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var DirectionLabel: UILabel!
    @IBOutlet weak var CentreView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        CentreView.layer.masksToBounds = true
        CentreView.layer.cornerRadius = 16
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func swipegesture(_ sender: UISwipeGestureRecognizer) {
        switch sender.direction {
        case .up:
            DirectionLabel.text = "Direction Up"
            CentreView.backgroundColor = UIColor.green
        case .down:
            DirectionLabel.text = "Direction Down"
            CentreView.backgroundColor = UIColor.purple
        case .left:
            DirectionLabel.text = "Direction Left"
            CentreView.backgroundColor = UIColor.blue
        case .right:
            DirectionLabel.text = "Direction Right"
            CentreView.backgroundColor = UIColor.cyan
        default:
            DirectionLabel.text = ""
        }
    }
    
}
